using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_for_nothing_1.Views.BoardColumns
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
