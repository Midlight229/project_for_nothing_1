using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project_for_nothing_1.Views.Projects
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
